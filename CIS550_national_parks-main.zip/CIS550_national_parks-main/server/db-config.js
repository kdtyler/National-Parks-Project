//database access credentials
module.exports = {
    host: "cis550-project-db.czp41uazuokk.us-east-1.rds.amazonaws.com",
  	port: "3306",
  	user: "cis550",
  	password: "cis550_2021",
  	database: "cis550_project"
};